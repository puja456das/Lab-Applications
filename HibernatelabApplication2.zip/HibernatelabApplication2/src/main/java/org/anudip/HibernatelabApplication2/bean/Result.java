package org.anudip.HibernatelabApplication2.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity
@Table(name = "results")
public class Result {
    @Id
    @Column(name = "roll_number")
    private String rollNumber;

    @Column(name = "half_yearly_total")
    private Double halfYearlyTotal;

    @Column(name = "annual_total")
    private Double annualTotal;

    private String grade;

    @OneToOne
    @JoinColumn(name = "roll_number")
    private Student student;
    
      //Constructors 
	public Result() {
		super();
		
	}

	public Result(String rollNumber, Double halfYearlyTotal, Double annualTotal, String grade, Student student) {
		super();
		this.rollNumber = rollNumber;
		this.halfYearlyTotal = halfYearlyTotal;
		this.annualTotal = annualTotal;
		this.grade = grade;
		this.student = student;
	}
	// getter and setter method
	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public Double getHalfYearlyTotal() {
		return halfYearlyTotal;
	}

	public void setHalfYearlyTotal(Double halfYearlyTotal) {
		this.halfYearlyTotal = halfYearlyTotal;
	}

	public Double getAnnualTotal() {
		return annualTotal;
	}

	public void setAnnualTotal(Double annualTotal) {
		this.annualTotal = annualTotal;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
    
	@Override
	public String toString() {
        return String.format("%-5s %-20s %-20s  %-5s", rollNumber, halfYearlyTotal, annualTotal, grade);
        		
	}

}
