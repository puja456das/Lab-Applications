package org.anudip.HibernatelabApplication2.application;

import org.anudip.HibernatelabApplication2.bean.Result;
import org.anudip.HibernatelabApplication2.bean.Student;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.anudip.HibernatelabApplication2.dao.DatabaseHandler;
import org.anudip.HibernatelabApplication2.bean.StudentNotFoundException;


import java.util.Scanner;

public class StudentMain {

    public static void insertRecord() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter roll number: ");
        String rollNumber = scanner.nextLine();

        System.out.println("Enter student name: ");
        String studentName = scanner.nextLine();

        System.out.println("Enter semester: ");
        String semester = scanner.nextLine();

        System.out.println("Enter half-yearly marks: ");
        Double halfYearlyTotal = scanner.nextDouble();

        // Create new Student object
        Student student = new Student();
        student.setRollNumber(rollNumber);
        student.setStudentName(studentName);
        student.setSemester(semester);

        // Create new Result object
        Result result = new Result();
        result.setRollNumber(rollNumber);
        result.setHalfYearlyTotal(halfYearlyTotal);
        result.setAnnualTotal(0.0); // Initialize annual total to 0
        result.setGrade(""); // Initialize grade to empty string

        // Save the student and result objects using Hibernate session
        Session session = null;
        Transaction transaction = null;

        try {
            session = DatabaseHandler.getDatabaseHandler().createSession();
            transaction = session.beginTransaction();

            session.save(student);
            session.save(result);

            transaction.commit();
            System.out.println("Record inserted successfully!");
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }

    public static void updateRecord() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter roll number to update record: ");
        String rollNumber = scanner.nextLine();

        Session session = null;
        Transaction transaction = null;

        try {
            session = DatabaseHandler.getDatabaseHandler().createSession();
            transaction = session.beginTransaction();

            // Retrieve the student based on roll number
            Student student = session.get(Student.class, rollNumber);

            if (student == null) {
                throw new StudentNotFoundException("Student not found.");
            }

            // Prompt user to enter marks
            System.out.println("Enter marks for English: ");
            Double englishMarks = scanner.nextDouble();

            System.out.println("Enter marks for Language: ");
            Double languageMarks = scanner.nextDouble();

            System.out.println("Enter marks for Mathematics: ");
            Double mathMarks = scanner.nextDouble();

            System.out.println("Enter marks for Science: ");
            Double scienceMarks = scanner.nextDouble();

            System.out.println("Enter marks for Social Study: ");
            Double socialStudyMarks = scanner.nextDouble();

            // Retrieve the corresponding result for the student
            Result result = session.get(Result.class, rollNumber);

            // Update the result object with new marks and recalculate grade
            double annualTotal = englishMarks + languageMarks + mathMarks + scienceMarks + socialStudyMarks;
            result.setAnnualTotal(annualTotal);
            //result.setEnglishMarks(englishMarks);
            //result.setLanguageMarks(languageMarks);
            //result.setMathMarks(mathMarks);
            //result.setScienceMarks(scienceMarks);
            //result.setSocialStudyMarks(socialStudyMarks);//
            result.setGrade(ResultService.gradeCalculation(result));

            // Update the result object in the database
            session.update(result);

            transaction.commit();
            System.out.println("Record updated successfully!");
        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }

    public static void displayRecord() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter roll number to display record: ");
        String rollNumber = scanner.nextLine();

        Session session = null;

        try {
            session = DatabaseHandler.getDatabaseHandler().createSession();

            // Retrieve the student based on roll number
            Student student = session.get(Student.class, rollNumber);

            if (student == null) {
                throw new StudentNotFoundException("Student not found.");
            }

            // Retrieve the corresponding result for the student
            Result result = session.get(Result.class, rollNumber);

            // Display student details
            System.out.println("Student Details:");
            System.out.println("Roll Number: " + student.getRollNumber());
            System.out.println("Student Name: " + student.getStudentName());
            System.out.println("Semester: " + student.getSemester());

            // Display result details
            System.out.println("\nResult Details:");
            System.out.println("Half Yearly Total: " + result.getHalfYearlyTotal());
            System.out.println("Annual Total: " + result.getAnnualTotal());
            System.out.println("Grade: " + result.getGrade());

        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Student Entry");
            System.out.println("2. Result Update");
            System.out.println("3. Show Student");
            System.out.println("4. Exit");

            System.out.println("\nEnter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    insertRecord();
                    break;
                case 2:
                    updateRecord();
                    break;
                case 3:
                    displayRecord();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }

        } while (choice != 4);
    }
}

