package org.anudip.LabSubmission.service;

import org.springframework.stereotype.Service;

@Service
public class CalculatorService {
	
   

	        public  String performCalculation(int i, int j, String k) {
	    		int r=0;
	    		String result="";
	    		switch(k) {
	    		case "+": r=i+j;result=""+r;break;
	    		case "-": r=i-j;result=""+r;break;
	    		case "*": r=i*j;result=""+r;break;
	    		case "/": r=i/j;result=""+r;break;
	    		case "%": r=i%j;result=""+r;break;
	    		default:result="ABCD";
	    		}
	    		return result;
	        }
}