package org.anudip.LabSubmission.exception;

public class OperatorException extends RuntimeException {

}
