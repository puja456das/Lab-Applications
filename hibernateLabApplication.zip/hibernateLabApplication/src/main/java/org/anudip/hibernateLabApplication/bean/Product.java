package org.anudip.hibernateLabApplication.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Entity
@Table(name = "Product")
public class Product implements Comparable<Product> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Product_Id")
    private Integer productId;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "purchase_price")
    private Double purchasedPrice;

    @Column(name = "sales_price")
    private Double salesPrice;

    @Column(name = "grade")
    private String grade;
    
    

    // Constructors, getters, setters, and other methods

    public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
    

	public Product(Integer productId, String productName, Double purchasedPrice, Double salesPrice, String grade) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.purchasedPrice = purchasedPrice;
		this.salesPrice = salesPrice;
		this.grade = grade;
	}


	public Integer getProductId() {
		return productId;
	}


	public void setProductId(Integer productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public Double getPurchasedPrice() {
		return purchasedPrice;
	}


	public void setPurchasedPrice(Double purchasedPrice) {
		this.purchasedPrice = purchasedPrice;
	}


	public Double getSalesPrice() {
		return salesPrice;
	}


	public void setSalesPrice(Double salesPrice) {
		this.salesPrice = salesPrice;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}


	@Override
    public int compareTo(Product other) {
        return this.productId.compareTo(other.productId);
    }

    @Override
    public String toString() {
        return String.format("%-5s %-20s %-10s %-10s %-5s", productId, productName, purchasedPrice, salesPrice, grade);
    }
}
