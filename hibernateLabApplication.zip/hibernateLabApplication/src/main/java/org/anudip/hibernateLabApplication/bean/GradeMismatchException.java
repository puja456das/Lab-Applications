package org.anudip.hibernateLabApplication.bean;
import javax.persistence.*;
public class GradeMismatchException extends RuntimeException {
    public GradeMismatchException(String message) {
        super(message);
    }
}
