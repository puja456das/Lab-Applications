package org.anudip.lab;

import java.util.Scanner;

	public class ShowRoom
	{
	    private String name; //Customer name
	    private long mobno; //for mobile number of the customer
	    private double cost; //to store the cost of the items purchased
	    private double dis; //for the cost of the items purchased
	    private double amount; //to store the discount amount

	    public ShowRoom()
	    {
	        name = "";
	        mobno = 0;
	        cost = 0.0;
	        dis = 0.0;
	        amount = 0.0;
	    }
      //input method for inputing customer details
	    public void input() {
	        Scanner in = new Scanner(System.in);
	        System.out.print("Enter customer name: ");
	        name = in.nextLine();
	        System.out.print("Enter customer mobile no: ");
	        mobno = in.nextLong();
	        System.out.print("Enter cost: ");
	        cost = in.nextDouble();
	    }
	    //this method calculate the discount on the purchased item
	    public void calculate() {
	        int disPercent = 0;
	        if (cost <= 10000)
	            disPercent = 5;
	        else if (cost <= 20000)
	            disPercent = 10;
	        else if (cost <= 35000)
	            disPercent = 15;
	        else
	            disPercent = 20;
	        
	        dis = cost * disPercent / 100.0;
	        amount = cost - dis;
	    }
	    //This method display the customer name,mobile and amount
	    
	    public void display() {
	        System.out.println("Customer Name: " + name);
	        System.out.println("Mobile Number: " + mobno);
	        System.out.println("Amout after discount: " + amount);
	    }
	    //main method
	    public static void main(String args[]) {
	    	//Object of ShowRoom
	        ShowRoom obj = new ShowRoom();
	        obj.input();
	        obj.calculate();
	        obj.display();
	    }
	}


