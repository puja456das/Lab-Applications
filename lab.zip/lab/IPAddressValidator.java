package org.anudip.lab;

import java.util.Scanner;

public class IPAddressValidator {

	public static boolean isValidIP (String ipAddress) {
	//Verifying IP address is valid or not
	        String ipPattern = "^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)$";
	        return ipAddress.matches(ipPattern);
	    }
	public static void main(String[] args) {
			
		//taking input from the user
		Scanner scanner = new Scanner(System.in);
	    System.out.print("Enter an IP address: ");
	    String ipAddress = scanner.nextLine();
	  //display the input IP address is valid or not
	    if (isValidIP(ipAddress)) {
	        System.out.println(ipAddress + " is valid");
	    } else {
	        System.out.println(ipAddress + " is Invalid");
	    }
	    scanner.close();
		}//end of main
	 }//end of class
		

	


