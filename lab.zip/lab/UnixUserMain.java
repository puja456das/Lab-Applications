package lab;

import java.util.*;

public class UnixUserMain {
    public static boolean checkPrime(int no) {
        if (no <= 1) {
            return false; // Numbers less than or equal to 1 are not prime
        }
        if (no <= 3) {
            return true; // 2 and 3 are prime numbers
        }
        if (no % 2 == 0 || no % 3 == 0) {
            return false; // Multiples of 2 and 3 are not prime
        }

        // Check for prime numbers in the form of 6k +/- 1
        for (int i = 5; i * i <= no; i += 6) {
            if (no % i == 0 || no % (i + 2) == 0) {
                return false; // If divisible by i or i+2, it's not prime
            }
        }

        return true;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of Unix user IDs to create: ");
        int numUsers = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Set<UnixUser> userSet = new LinkedHashSet<>(); // Use LinkedHashSet to maintain order of entry

        for (int i = 0; i < numUsers; i++) {
            System.out.println("Enter user details (employeeId, name, userType) separated by commas:");
            String userDetails = scanner.nextLine();
            String[] userDetailsArray = userDetails.split(",");

            if (userDetailsArray.length != 3) {
                System.out.println("Invalid input format. Please use the format 'employeeId, name, userType'");
                i--; // Decrement i to re-enter user details
                continue;
            }

            try {
                int employeeId = Integer.parseInt(userDetailsArray[0]);
                String name = userDetailsArray[1].trim();
                String userType = userDetailsArray[2].trim();

                // Check if employeeId is already in use
                UnixUser user = new UnixUser(null, employeeId, null, null);
                if (userSet.contains(user)) {
                    System.out.println("Employee ID must be unique. Please enter a different employee ID.");
                    i--; // Decrement i to re-enter user details
                    continue;
                }

                int userId;
                if (userType.equalsIgnoreCase("Super")) {
                    userId = generatePrimeUserId(userSet);
                } else {
                    userId = generateNonPrimeUserId(userSet);
                }

                // Create a UnixUser object and add it to the set
                user = new UnixUser(userId, employeeId, name, userType);
                userSet.add(user);
            } catch (NumberFormatException e) {
                System.out.println("Invalid employeeId. Please enter a valid number.");
                i--; // Decrement i to re-enter user details
            }
        }

        scanner.close();

        // Display the Unix users in tabular format
        System.out.println("\nUser Id    Employee Id     User Name            User Type");
        for (UnixUser user : userSet) {
            System.out.printf("%-10s %-15s %-20s %-10s%n", user.getUserId(), user.getEmployeeId(),
                    user.getUsername(), user.getUserType());
        }
    }

    private static int generatePrimeUserId(Set<UnixUser> userSet) {
        int userId = 1001;
        while (true) {
            if (checkPrime(userId) && !isUserIdInSet(userId, userSet)) {
                return userId;
            }
            userId++;
        }
    }

    private static int generateNonPrimeUserId(Set<UnixUser> userSet) {
        int userId = 1001;
        while (true) {
            if (!checkPrime(userId) && !isUserIdInSet(userId, userSet)) {
                return userId;
            }
            userId++;
        }
    }

    private static boolean isUserIdInSet(int userId, Set<UnixUser> userSet) {
        for (UnixUser user : userSet) {
            if (user.getUserId() == userId) {
                return true;
            }
        }
        return false;
    }
}
