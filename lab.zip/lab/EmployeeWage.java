package org.anudip.lab;

import java.util.Scanner;

class EmployeeWage {
	 public static String convertToTwoDecimalPlace(double value) {
		  return String.format("%.2f", value);
		     }

  public static void main(String[] args) {
	 Scanner scanner = new Scanner(System.in);
     System.out.print("Enter the number of workers at the site: ");
		    int numWorkers = scanner.nextInt();

		// Check if the number of workers is at least 5
		       if (numWorkers < 5) {
		        System.out.println("Wrong workers number");
		            scanner.close();
		             return;
		         }
		       double totalWage = 0;
		         for (int i = 1; i <= numWorkers; i++) {
		        System.out.print("Enter the daily wage of worker " + i + ": ");
		          double wage = scanner.nextDouble();

   // Check if the wage is within the valid range (100.00 to 250.00)
		      if (wage < 100.00 || wage > 250.00) {
		      System.out.println("WageException: Invalid wage value for worker " + i + ". Please re-enter.");
		        i--; // Ask to re-enter the wage for the current worker
		         continue;
		  }

		         totalWage += wage;
	      }

		      double averageWage = totalWage / numWorkers;
		         System.out.println("Total wage expense for the site: " + convertToTwoDecimalPlace(totalWage));
		         System.out.println("Average wage for the site: " + convertToTwoDecimalPlace(averageWage));

		         scanner.close();
		         
      }
		 
}


