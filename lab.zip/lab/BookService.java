package org.anudip.lab;

import java.util.List;
import java.util.Comparator;

 public class BookService {
    public List<Book> arrangeBooksNumberWise(List<Book> bookList) {
        // Sort the books by book number in ascending order
        bookList.sort(Comparator.comparing(Book::getBookNumber));
        return bookList;
    }

    public List<Book> arrangeBooksTitleWise(List<Book> bookList) {
        // Sort the books by book title in ascending order
        bookList.sort(Comparator.comparing(Book::getBookTitle));
        return bookList;
    }

    public List<Book> arrangeBooksAuthorWise(List<Book> bookList) {
        // Sort the books by author's name in ascending order
        bookList.sort(Comparator.comparing(Book::getAuthor));
        return bookList;
    }
}

