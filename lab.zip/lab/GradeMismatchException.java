package org.anudip.lab;

public class GradeMismatchException extends RuntimeException{
	static final long serialVersionUID=1L;
	 public GradeMismatchException(String message) { 
		
			super(message); 

}
}
