package lab;

public class PermanentEmployee extends Employee {
	private Double monthlySalary;
	private Double pf;
	private Double tax;
	private static int idGen = 1001; //Initial value for Id generation
	
	public PermanentEmployee(String employeeId, String employeeName, String department, Double monthlySalary, Double pf,
			Double tax) {
		super(employeeId, employeeName, department);
		this.monthlySalary = monthlySalary;
		this.pf = 0.15 * monthlySalary;
		this.tax = tax;
		this.setEmployeeId(generateId());
	}

	public Double getMonthlySalary() {
		return monthlySalary;
	}

	public void setMonthlySalary(Double monthlySalary) {
		this.monthlySalary = monthlySalary;
	}

	public Double getPf() {
		return pf;
	}

	public void setPf(Double pf) {
		this.pf = pf;
	}

	public Double getTax() {
		return tax;
	}

	public void setTax(Double tax) {
		this.tax = tax;
	}

	public static int getIdGen() {
		return idGen;
	}

	public static void setIdGen(int idGen) {
		PermanentEmployee.idGen = idGen;
	}

	// Tax calculation method override
	@Override
	public void calculateTax() {
	    double annualSalary = monthlySalary * 12; // Assuming 12 months in a year
	    this.tax = 0.1 * annualSalary;
	}

	@Override
	public String toString() {
		String output = String.format("%-15s %-15s %-15s %-15s %-15s %-15s",
                getEmployeeId(), getEmployeeName(), getDepartment(),
                monthlySalary, pf, tax);
				return output;
	}
	
	// Static method to generate employee IDs
    public static String generateId() {
        return "P" + idGen++;
    }
}