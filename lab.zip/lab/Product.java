package org.anudip.lab;

public class Product {
	private Integer id;
	private String name;
	private Double purchasedPrice;
	private Double salesPrice;
	private String grade;
	
	private static int idGenerator=100;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getPurchasedPrice() {
		return purchasedPrice;
	}

	public void setPurchasedPrice(Double purchasedPrice) {
		this.purchasedPrice = purchasedPrice;
	}

	public Double getSalesPrice() {
		return salesPrice;
	}

	public void setSalesPrice(Double salesPrice) {
		this.salesPrice = salesPrice;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}
	

	public Product(Integer id, String name, Double purchasedPrice, Double salesPrice, String grade) {
		super();
		this.id = ++idGenerator;
		this.name = name;
		this.purchasedPrice = purchasedPrice;
		this.salesPrice = salesPrice;
		this.grade = grade;
	}

	@Override
	public String toString() {
		String output=String.format("%-5s %-20s %-10s %-10s %-5s",id,name,purchasedPrice,salesPrice,grade);
		return output;
	}
}

	
	
	


