package org.anudip.lab;

//Declaring the class User
public class User {
	private String userId; //Declaring private String userId method
	private String password; //Declaring private String password method
	
	//Constructors
	public User(String userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}
	public String getUserId() { //Getter for userId
		return userId;
	}
	public void setUserId(String userId) { //Setter for userId
		this.userId = userId;
	}
	public String getPassword() { //Getter for password
		return password;
	}
	public void setPassword(String password) { //Setter for password
		this.password = password;
	}
	
}
