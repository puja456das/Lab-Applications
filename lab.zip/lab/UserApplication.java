package org.anudip.lab;

import java.util.ArrayList;
import java.util.List;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Scanner;
//Declaring the class UserApplication
public class UserApplication {
	//Private attribute to hold user data
	private static List<User>userList=new ArrayList<>();
	
	//Method to load user data from file into the list
	  public static void uploadToList() {
	       try (BufferedReader reader = new BufferedReader(new FileReader("d:/UserMaster.txt"))){
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] parts = line.split(",");
	                if (parts.length == 2) {
	                    userList.add(new User(parts[0].trim(), parts[1].trim()));
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    public static void main(String[] args) {
	    	 //Load user data from file into the list
	        uploadToList();
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter User Id:");
	        String userId = scanner.nextLine();

	        System.out.println("Enter Password:");
	        String password = scanner.nextLine();

	        boolean isValidUser = false;
	        for (User user : userList) {
	        	//Check if entered user id and password match stored data
	            if (user.getUserId().equals(userId) && user.getPassword().equals(password)) {
	                isValidUser = true;
	                break;
	            }
	        }
	        //Display result of authentication
	        if (isValidUser) {
	            System.out.println("Valid User");
	        } else {
	            System.out.println("Invalid User");
	        }

	         }
}