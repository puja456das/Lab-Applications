package lab;

public class ContractEmployee extends Employee {
	
	private Integer contractPeriod;
	private Double contractAmount;
	private Double tax;
	private static int idGenerator = 2001; //Initial value for Id generation
	
	public ContractEmployee(String employeeId, String employeeName, String department,Integer contractPeriod, Double contractAmount, Double tax) {
		super(employeeId, employeeName, department);
		this.contractPeriod = contractPeriod;
		this.contractAmount = contractAmount;
		this.tax = tax;
		this.setEmployeeId(generateId());
	}
	//Getter and Setter method
	public Integer getContractPeriod() {
		return contractPeriod;
	}

	public void setContractPeriod(Integer contractPeriod) {
		this.contractPeriod = contractPeriod;
	}

	public Double getContractAmount() {
		return contractAmount;
	}

	public void setContractAmount(Double contractAmount) {
		this.contractAmount = contractAmount;
	}

	public Double getTax() {
		return tax;
	}

	public void setTax(Double tax) {
		this.tax = tax;
	}

	public static int getIdGenerator() {
		return idGenerator;
	}

	public static void setIdGenerator(int idGenerator) {
		ContractEmployee.idGenerator = idGenerator;
	}
	
	// Tax calculation method override
		//@Override
		public void calculateTax() {
		    this.tax = 0.1 * contractAmount;
		}

		@Override
		public String toString() {
			String output = String.format("%-15s %-15s %-15s %-15s %-15s %-15s",
					getEmployeeId(), getEmployeeName(), getDepartment(),
	                contractPeriod, contractAmount, tax);
			return output;
		}
		
		// Static method to generate employee IDs
	    public static String generateId() {
	        return "C" + idGenerator++;
	    }

}
