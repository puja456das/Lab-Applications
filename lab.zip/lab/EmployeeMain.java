package lab;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class EmployeeMain{
	
	  public static void main(String[] args) {
	      Scanner scanner = new Scanner(System.in);

	    System.out.print("Enter Number of Employees: ");
	    int numEmployees = scanner.nextInt();
	    scanner.nextLine(); // Consume newline

	    List<Employee> permanentEmployees = new ArrayList<>();
	    List<Employee> contractEmployees = new ArrayList<>();

	    System.out.println("Enter all Employees details...");

	    for (int i = 0; i < numEmployees; i++) {
	     String employeeDetails = scanner.nextLine();
	     String[] details = employeeDetails.split(",");

	     String name = details[0].trim();
	     String department = details[1].trim();

	       if (details.length == 3) {
	       Double monthlySalary = Double.parseDouble(details[2].trim());
	       PermanentEmployee permanentEmployee = new PermanentEmployee("employeeId", name, department, monthlySalary, 0.00, 0.00);
	       permanentEmployee.calculateTax(); // Calculate tax
	       permanentEmployees.add(permanentEmployee);
	          } else if (details.length == 4) {
	          Integer contractPeriod = Integer.parseInt(details[2].trim());
	          Double contractAmount = Double.parseDouble(details[3].trim());
	          ContractEmployee contractEmployee = new ContractEmployee("employeeId", name, department, contractPeriod, contractAmount, 0.0);
	          contractEmployee.calculateTax(); // Calculate tax
	          contractEmployees.add(contractEmployee);
	            }
	        }

	        Collections.sort(permanentEmployees);
	        Collections.sort(contractEmployees, Collections.reverseOrder());

	        System.out.println("\nPermanent Employee List\n");
	        System.out.println("Id              Name             Department      Salary         PF             Tax");
	        for (Employee employee : permanentEmployees) {
	            System.out.println(employee);
	        }

	        System.out.println("\nContract Employee List\n");
	        System.out.println("Id               Name            Department     Period         Amount          Tax");
	        for (Employee employee : contractEmployees) {
	            System.out.println(employee);
	        }
	    }
	}
	


