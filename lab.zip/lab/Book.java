package org.anudip.lab;

//Declaring the Book class

public class Book {
	
	private Integer bookNumber;//Declaring private Integer bookNumber Method
	private String bookTitle; //Declaring private String bookTitle Method
	private String author; //Declaring private String author Method
	
	//Constructors
	public Book(Integer bookNumber, String bookTitle, String author) {
		super();
		this.bookNumber = bookNumber;
		this.bookTitle = bookTitle;
		this.author = author;
	}
	public Integer getBookNumber() {  //Getter for bookNumber
		return bookNumber;
	}
	public void setBookNumber(Integer bookNumber) {  //Setter for bookNumber
		this.bookNumber = bookNumber;
	}
	public String getBookTitle() {  //Getter for bookTitle
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {  //Setter for bookTitle
		this.bookTitle = bookTitle;
	}
	public String getAuthor() {  //Getter for author
		return author;
	}
	public void setAuthor(String author) {  //Setter for author
		this.author = author;
	}
	//Override to String()
	@Override
	public String toString() {
		return String.format("%-10s %-35s %-20s ", bookNumber,bookTitle,author);

		 
	}//end of String to String Method
	
}//end of Consumer Class
