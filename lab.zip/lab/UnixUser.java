package lab;

import java.util.Objects;

public class UnixUser {
	// Member variables for UnixUser
	private Integer userId;
    private Integer employeeId;
    private	String username;
    private String userType;
    
 // Constructor to initialize UnixUser object
	public UnixUser(Integer userId, Integer employeeId, String username, String userType) {
		super();
		this.userId = userId;
		this.employeeId = employeeId;
		this.username = username;
		this.userType = userType;
	}
	 // Getter method for userId
	public Integer getUserId() {
		return userId;
	}
	// Setter method for userId
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	// Getter method for employeeId
	public Integer getEmployeeId() {
		return employeeId;
	}
	// Setter method for employeeId
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	// Getter method for username
	public String getUsername() {
		return username;
	}
    // Setter method for username
    public void setUsername(String username) {
		this.username = username;
	}
   // Getter method for userType
	public String getUserType() {
		return userType;
	}
	// Setter method for userType
	public void setUserType(String userType) {
		this.userType = userType;
	}
	// Override the toString() method to provide a custom string representation
	@Override
	public String toString() {
		 String output =String.format("%-10s %-10s %-20s %-10s");
		return output;
	}
	// Override the hashCode() method to generate a unique hash code for each object
	@Override
	public int hashCode() {
		return Objects.hash(employeeId, userId, userType, username);
	}
	// Override the equals() method to compare two objects for equality based on their attributes
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UnixUser other = (UnixUser) obj;
		return Objects.equals(employeeId, other.employeeId) && Objects.equals(userId, other.userId)
				&& Objects.equals(userType, other.userType) && Objects.equals(username, other.username);
	}
	
	
}
