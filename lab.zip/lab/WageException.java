package org.anudip.lab;

public class WageException extends Exception {
	public WageException(String message) {
        super(message);
    }
}


