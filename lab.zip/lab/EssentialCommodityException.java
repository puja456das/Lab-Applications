package org.anudip.lab;

public class EssentialCommodityException extends RuntimeException{
	static final long serialVersionUID=2L;
	 public EssentialCommodityException(String message) { 
		
			super(message); 
	 }

}
