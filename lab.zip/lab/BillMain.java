package org.anudip.lab;

import java.util.Scanner;

public class BillMain {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter the number of consumers: ");
	        int numConsumers = scanner.nextInt();

	        if (numConsumers <= 0) {
	            System.out.println("Invalid input.");
	            scanner.close();
	            return;
	        }

	        Consumer[] consumers = new Consumer[numConsumers];

	        for (int i = 0; i < numConsumers; i++) {
	            System.out.print("Enter details of consumer number " + (i + 1) + " (id,name,unitConsumed): ");
	            String input = scanner.next();
	            String[] details = input.split(",");
	            String id = details[0];
	            String name = details[1];
	            int unitConsumed = Integer.parseInt(details[2]);

	            consumers[i] = new Consumer(id, name, unitConsumed);
	        }

	        System.out.println("\nBill Details:");
	        System.out.println("ID    Name                 Unit      Amount");
	        System.out.println("--------------------------------------------");

	        for (Consumer consumer : consumers) {
	            String finalPayment = BillService.billCalculation(consumer);
	            System.out.println(consumer);
	        }

	        scanner.close();
	    } //end of main method
	

	} //end of class


